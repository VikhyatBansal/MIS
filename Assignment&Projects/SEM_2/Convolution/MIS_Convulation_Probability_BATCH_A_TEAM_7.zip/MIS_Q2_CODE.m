seq = [1,1];
temp = seq;
% perform convolution 20 times on the sequence

for i = 1:20

    seq_length = length(seq);
    temp_length = length(temp);

    temp_padded = [temp zeros(1, temp_length)];
    %adding additional 0 to match the array size 
    zero_for_seq = length(temp_padded) - seq_length;
    seq_padded = [seq zeros(1, zero_for_seq)];
    %convolution
    temp = ifft(fft(seq_padded).*fft(temp_padded))
    %temp is the result we need 
end
