A = [14 7 42;0 -15 -36]
Current = rref(A)         %Current is in following form [i3;i2]
i1 = 3
ix = 3 - Current(1,3)