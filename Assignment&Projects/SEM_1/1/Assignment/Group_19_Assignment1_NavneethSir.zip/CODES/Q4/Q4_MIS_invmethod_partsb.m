A = [14 7;0 -15]
B = [42;-36]
Current = inv(A)*B         %Current is in following form [i3;i2]
i1 = 3;
ix = 3 - Current(1,1)