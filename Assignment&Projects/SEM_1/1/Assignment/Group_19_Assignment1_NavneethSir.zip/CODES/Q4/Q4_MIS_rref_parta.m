A = [-8 14 6;7 14 42]
Current = rref(A)            %Current = [i1;i2]
i1 = 3;
ix = i1 - Current(2,3)