NUMBER_OF_DISCS= 64;
TOTAL_NUMBER_OF_MOVES= (2^NUMBER_OF_DISCS)-1;
disp('Time required for  the collapse of the world according to the myth is -');
disp(TOTAL_NUMBER_OF_MOVES);